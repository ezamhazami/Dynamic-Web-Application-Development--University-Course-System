INSERT INTO academic (username, password) VALUES
('acadmin', 'academic23');

